import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractMetadata {
    public static void main(String[] args) {
        File folder = new File("dummy_exes");
        File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".exe"));
        if (files == null || files.length == 0) {
            System.out.println("No .exe files found in dummy_exes directory.");
            return;
        }

        List<String> jsonEntries = new ArrayList<>();
        for (File file : files) {
            try {
                byte[] fileData = Files.readAllBytes(file.toPath());
                Map<String, Object> peHeader = extractPeHeader(fileData);
                List<String> extractedStrings = extractStrings(fileData);

                String jsonEntry = buildJsonEntry(file.getName(), peHeader, extractedStrings);
                jsonEntries.add(jsonEntry);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String jsonOutput = "[\n" + String.join(",\n", jsonEntries) + "\n]";
        try {
            Files.write(Paths.get("benign_pe_metadata.json"), jsonOutput.getBytes("UTF-8"));
            System.out.println("Metadata extracted and saved to benign_pe_metadata.json");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Extracts simulated PE header information from the binary data.
     */
    private static Map<String, Object> extractPeHeader(byte[] data) {
        Map<String, Object> header = new HashMap<>();
        if (data.length >= 2 && data[0] == 'M' && data[1] == 'Z') {
            header.put("Magic", "MZ");
        } else {
            header.put("Magic", "Unknown");
        }

        byte[] peSignature = new byte[]{'P', 'E', 0, 0};
        int peIndex = indexOf(data, peSignature);
        if (peIndex != -1) {
            int start = peIndex + 4;
            if (data.length >= start + 8) {
                // Machine: 2 bytes
                byte b0 = data[start];
                byte b1 = data[start + 1];
                if (b0 == 0x4c && b1 == 0x01) {
                    header.put("Machine", "Intel 386");
                } else if (b0 == 0x64 && b1 == (byte) 0x86) {
                    header.put("Machine", "AMD64");
                } else {
                    header.put("Machine", "Unknown");
                }
                // Number of Sections: 2 bytes (little endian)
                int numberOfSections = (data[start + 2] & 0xff) | ((data[start + 3] & 0xff) << 8);
                header.put("NumberOfSections", numberOfSections);
                // TimeDateStamp: 4 bytes (little endian)
                int timeDateStamp = (data[start + 4] & 0xff) 
                        | ((data[start + 5] & 0xff) << 8)
                        | ((data[start + 6] & 0xff) << 16)
                        | ((data[start + 7] & 0xff) << 24);
                header.put("TimeDateStamp", timeDateStamp);
            } else {
                header.put("Machine", "Incomplete");
                header.put("NumberOfSections", "Incomplete");
                header.put("TimeDateStamp", "Incomplete");
            }
        } else {
            header.put("PE_Signature", "Not found");
        }
        return header;
    }

    /**
     * Searches for the specified byte pattern in the data and returns its index or -1 if not found.
     */
    private static int indexOf(byte[] data, byte[] pattern) {
        outer:
        for (int i = 0; i <= data.length - pattern.length; i++) {
            for (int j = 0; j < pattern.length; j++) {
                if (data[i + j] != pattern[j]) {
                    continue outer;
                }
            }
            return i;
        }
        return -1;
    }

    /**
     * Extracts sequences of printable ASCII characters (length >= 4) from the file data.
     */
    private static List<String> extractStrings(byte[] data) {
        List<String> strings = new ArrayList<>();
        try {
            // Use ISO-8859-1 encoding to map each byte to a character without data loss.
            String content = new String(data, "ISO-8859-1");
            // Regex: [\x20-\x7E]{4,} matches printable ASCII sequences of length 4 or more.
            Pattern pattern = Pattern.compile("[\\x20-\\x7E]{4,}");
            Matcher matcher = pattern.matcher(content);
            while (matcher.find()) {
                strings.add(matcher.group());
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return strings;
    }

    /**
     * Builds a JSON entry string for a single file's metadata.
     */
    private static String buildJsonEntry(String fileName, Map<String, Object> peHeader, List<String> strings) {
        StringBuilder sb = new StringBuilder();
        sb.append("  {\n");
        sb.append("    \"file_name\": \"").append(escapeJson(fileName)).append("\",\n");
        sb.append("    \"pe_header\": {\n");
        List<String> headerEntries = new ArrayList<>();
        for (Map.Entry<String, Object> entry : peHeader.entrySet()) {
            headerEntries.add("      \"" + escapeJson(entry.getKey()) + "\": \"" + escapeJson(entry.getValue().toString()) + "\"");
        }
        sb.append(String.join(",\n", headerEntries));
        sb.append("\n    },\n");
        sb.append("    \"strings\": [\n");
        List<String> stringEntries = new ArrayList<>();
        for (String s : strings) {
            stringEntries.add("      \"" + escapeJson(s) + "\"");
        }
        sb.append(String.join(",\n", stringEntries));
        sb.append("\n    ]\n");
        sb.append("  }");
        return sb.toString();
    }

    /**
     * Escapes special characters for JSON strings.
     */
    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
