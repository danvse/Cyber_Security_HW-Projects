import json

indicators = ["encrypt", "tor:", ".onion"]

def is_suspicious(strings):
    has_encrypt = any("encrypt" in s.lower() for s in strings)
    has_tor_or_onion = any(
        ("tor:" in s.lower()) or (".onion" in s.lower())
        for s in strings
    )
    return has_encrypt and has_tor_or_onion


def main():
    with open("benign_pe_metadata.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    
    suspicious_files = []
    for entry in data:
        file_name = entry.get("file_name", "")
        strings = entry.get("strings", [])
        
        if is_suspicious(strings):
            suspicious_files.append(file_name)
    
    if suspicious_files:
        print("Suspicious files found:")
        for f in suspicious_files:
            print(f"- {f}")
    else:
        print("No suspicious files detected.")

if __name__ == "__main__":
    main()
