#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    volatile int modified;
    char buffer[64];

    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input>\n", argv[0]);
        exit(1);
    }

    modified = 0;
    strcpy(buffer, argv[1]); // Vulnerable: no bounds checking

    if (modified != 0) {
        printf("You have changed the 'modified' variable\n");
    } else {
        printf("Try again\n");
    }

    return 0;
}