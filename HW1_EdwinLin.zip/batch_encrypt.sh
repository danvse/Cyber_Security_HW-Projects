#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 <public_key.pem>"
    exit 1
fi

PUBLIC_KEY="$1"

if [ ! -f "$PUBLIC_KEY" ]; then
    echo "Error: Public key file '$PUBLIC_KEY' does not exist."
    exit 1
fi

for FILE in *.txt; do
    [ -e "$FILE" ] || { echo "No .txt files to encrypt."; exit 1; }

    OUTPUT_FILE="${FILE}.enc"

    openssl rsautl -encrypt -inkey "$PUBLIC_KEY" -pubin -in "$FILE" -out "$OUTPUT_FILE"

    if [ $? -eq 0 ]; then
        echo "Encrypted '$FILE' -> '$OUTPUT_FILE'"
    else
        echo "Failed to encrypt '$FILE'"
    fi
done

