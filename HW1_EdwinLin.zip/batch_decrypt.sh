#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Usage: $0 <private_key.pem>"
    exit 1
fi

PRIVATE_KEY="$1"

if [ ! -f "$PRIVATE_KEY" ]; then
    echo "Error: Private key file '$PRIVATE_KEY' does not exist."
    exit 1
fi

for FILE in *.enc; do
    [ -e "$FILE" ] || { echo "No .enc files to decrypt."; exit 1; }

    OUTPUT_FILE="${FILE%.enc}.decrypted.txt"

    openssl rsautl -decrypt -inkey "$PRIVATE_KEY" -in "$FILE" -out "$OUTPUT_FILE"

    if [ $? -eq 0 ]; then
        echo "Decrypted '$FILE' -> '$OUTPUT_FILE'"
    else
        echo "Failed to decrypt '$FILE'"
    fi
done

