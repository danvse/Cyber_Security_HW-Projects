if [ $# -ne 3 ]; then
    echo "Usage: $0 <file_to_sign> <private_key.pem> <public_key.pem>"
    exit 1
fi

FILE="$1"
PRIVATE_KEY="$2"
PUBLIC_KEY="$3"

if [ ! -f "$FILE" ]; then
    echo "Error: File '$FILE' does not exist."
    exit 1
fi

if [ ! -f "$PRIVATE_KEY" ]; then
    echo "Error: Private key file '$PRIVATE_KEY' does not exist."
    exit 1
fi

if [ ! -f "$PUBLIC_KEY" ]; then
    echo "Error: Public key file '$PUBLIC_KEY' does not exist."
    exit 1
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
TIMESTAMPED_FILE="${FILE}.timestamped"
SIGNATURE_FILE="${FILE}.sig"

cp "$FILE" "$TIMESTAMPED_FILE"
echo "Timestamp: $TIMESTAMP" >> "$TIMESTAMPED_FILE"

openssl dgst -sha256 -sign "$PRIVATE_KEY" -out "$SIGNATURE_FILE" "$TIMESTAMPED_FILE"

if [ $? -ne 0 ]; then
    echo "Signing failed"
    rm -f "$TIMESTAMPED_FILE"
    exit 1
fi

echo "Signature created: $SIGNATURE_FILE"
echo "Verifying signature..."

openssl dgst -sha256 -verify "$PUBLIC_KEY" -signature "$SIGNATURE_FILE" "$TIMESTAMPED_FILE"

if [ $? -eq 0 ]; then
    echo "Signature is valid."

    SIGNED_TIMESTAMP=$(tail -n 1 "$TIMESTAMPED_FILE" | sed 's/^Timestamp: //')
    echo "File was signed at: $SIGNED_TIMESTAMP"
else
    echo "Signature is invalid."
fi

