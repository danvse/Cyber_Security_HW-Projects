if [ $# -ne 2 ]; then
    echo "Usage: $0 <file_to_sign> <private_key.pem>"
    exit 1
fi

FILE="$1"
PRIVATE_KEY="$2"

if [ ! -f "$FILE" ]; then
    echo "Error: File '$FILE' does not exist."
    exit 1
fi

if [ ! -f "$PRIVATE_KEY" ]; then
    echo "Error: Private key file '$PRIVATE_KEY' does not exist."
    exit 1
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
TEMP_FILE="${FILE}.timestamped"
SIGNATURE_FILE="${FILE}.sig"

cp "$FILE" "$TEMP_FILE"
echo "Timestamp: $TIMESTAMP" >> "$TEMP_FILE"

openssl dgst -sha256 -sign "$PRIVATE_KEY" -out "$SIGNATURE_FILE" "$TEMP_FILE"

if [ $? -eq 0 ]; then
    echo "Signature saved to '$SIGNATURE_FILE'"
    echo "Timestamped file: '$TEMP_FILE'"
else
    echo "Signing failed"
    rm -f "$TEMP_FILE"
fi

